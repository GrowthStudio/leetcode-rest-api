
# Problem

Given _numRows_, generate the first _numRows_ of Pascal's triangle.

For example, given _numRows_ = 5,

Return

[Subscribe](/subscribe/) to see which companies asked this question.



[Pascal's Triangle](https://leetcode.com/problems/pascals-triangle)

# Solution



