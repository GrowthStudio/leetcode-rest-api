
package _131_palindrome_partitioning;

/**
 * https://leetcode.com/problems/palindrome-partitioning
 */
public class Solution {
    public void palindromePartitioning() {

    }
}

