
# Problem

Given a string _s_, partition _s_ such that every substring of the partition
is a palindrome.

Return all possible palindrome partitioning of _s_.

For example, given _s_ = `"aab"`,

Return

[Subscribe](/subscribe/) to see which companies asked this question.



[Palindrome Partitioning](https://leetcode.com/problems/palindrome-partitioning)

# Solution



