
package _131_palindrome_partitioning;
import org.junit.*;

public class Tests {
	private Solution solution = new Solution();

	@Test public void test1() {

	}

    @Test public void test2() {

	}
}

