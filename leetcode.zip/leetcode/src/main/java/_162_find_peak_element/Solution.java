
package _162_find_peak_element;

/**
 * https://leetcode.com/problems/find-peak-element
 */
public class Solution {
    public void findPeakElement() {

    }
}

