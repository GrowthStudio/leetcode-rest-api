
package _035_search_insert_position;

/**
 * https://leetcode.com/problems/search-insert-position
 */
public class Solution {
    public void searchInsertPosition() {

    }
}

