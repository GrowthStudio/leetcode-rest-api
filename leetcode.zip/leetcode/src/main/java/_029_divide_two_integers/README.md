
# Problem

Divide two integers without using multiplication, division and mod operator.

If it is overflow, return MAX_INT.

[Subscribe](/subscribe/) to see which companies asked this question.



[Divide Two Integers](https://leetcode.com/problems/divide-two-integers)

# Solution



