
# Problem

Given two non-negative integers `num1` and `num2` represented as strings,
return the product of `num1` and `num2`.

**Note:**

[Subscribe](/subscribe/) to see which companies asked this question.



[Multiply Strings](https://leetcode.com/problems/multiply-strings)

# Solution



