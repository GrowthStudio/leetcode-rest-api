
# Problem

Given two words _word1_ and _word2_, find the minimum number of steps required
to convert _word1_ to _word2_. (each operation is counted as 1 step.)

You have the following 3 operations permitted on a word:

a) Insert a character

b) Delete a character

c) Replace a character

[Subscribe](/subscribe/) to see which companies asked this question.



[Edit Distance](https://leetcode.com/problems/edit-distance)

# Solution



