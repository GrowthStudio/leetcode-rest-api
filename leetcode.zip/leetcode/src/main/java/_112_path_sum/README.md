
# Problem

Given a binary tree and a sum, determine if the tree has a root-to-leaf path
such that adding up all the values along the path equals the given sum.

return true, as there exist a root-to-leaf path `5->4->11->2` which sum is 22.

[Subscribe](/subscribe/) to see which companies asked this question.



[Path Sum](https://leetcode.com/problems/path-sum)

# Solution



