
# Problem

Follow up for N-Queens problem.

Now, instead outputting board configurations, return the total number of
distinct solutions.

![](https://leetcode.com/static/images/problemset/8-queens.png)

[Subscribe](/subscribe/) to see which companies asked this question.



[N-Queens II](https://leetcode.com/problems/n-queens-ii)

# Solution



