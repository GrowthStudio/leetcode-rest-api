
package _052_n_queens_ii;

/**
 * https://leetcode.com/problems/n-queens-ii
 */
public class Solution {
    public void nQueensIi() {

    }
}

