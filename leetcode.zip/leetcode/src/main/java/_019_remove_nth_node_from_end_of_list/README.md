
# Problem

Given a linked list, remove the _n_th node from the end of list and return its
head.

For example,

**Note:**  
Given _n_ will always be valid.

Try to do this in one pass.

[Subscribe](/subscribe/) to see which companies asked this question.



[Remove Nth Node From End of List](https://leetcode.com/problems/remove-nth-node-from-end-of-list)

# Solution



