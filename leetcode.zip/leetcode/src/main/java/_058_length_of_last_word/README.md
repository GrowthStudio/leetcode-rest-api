
# Problem

Given a string _s_ consists of upper/lower-case alphabets and empty space
characters `' '`, return the length of last word in the string.

If the last word does not exist, return 0.

**Note:** A word is defined as a character sequence consists of non-space characters only.

For example,

Given _s_ = `"Hello World"`,

return `5`.

[Subscribe](/subscribe/) to see which companies asked this question.



[Length of Last Word](https://leetcode.com/problems/length-of-last-word)

# Solution



