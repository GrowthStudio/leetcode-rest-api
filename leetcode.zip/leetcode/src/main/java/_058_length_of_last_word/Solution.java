
package _058_length_of_last_word;

/**
 * https://leetcode.com/problems/length-of-last-word
 */
public class Solution {
    public void lengthOfLastWord() {

    }
}

