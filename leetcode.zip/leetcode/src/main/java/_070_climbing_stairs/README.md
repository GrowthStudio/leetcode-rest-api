
# Problem

You are climbing a stair case. It takes _n_ steps to reach to the top.

Each time you can either climb 1 or 2 steps. In how many distinct ways can you
climb to the top?

**Note:** Given _n_ will be a positive integer. 

[Subscribe](/subscribe/) to see which companies asked this question.



[Climbing Stairs](https://leetcode.com/problems/climbing-stairs)

# Solution



