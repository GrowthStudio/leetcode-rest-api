
# Problem

Merge _k_ sorted linked lists and return it as one sorted list. Analyze and
describe its complexity.

[Subscribe](/subscribe/) to see which companies asked this question.



[Merge k Sorted Lists](https://leetcode.com/problems/merge-k-sorted-lists)

# Solution



