
package _061_rotate_list;

/**
 * https://leetcode.com/problems/rotate-list
 */
public class Solution {
    public void rotateList() {

    }
}

