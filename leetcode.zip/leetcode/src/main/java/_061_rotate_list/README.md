
# Problem

Given a list, rotate the list to the right by _k_ places, where _k_ is non-
negative.

For example:

Given `1->2->3->4->5->NULL` and _k_ = `2`,

return `4->5->1->2->3->NULL`.

[Subscribe](/subscribe/) to see which companies asked this question.



[Rotate List](https://leetcode.com/problems/rotate-list)

# Solution



