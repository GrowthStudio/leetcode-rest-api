
# Problem

Given a collection of integers that might contain duplicates, **_nums_**,
return all possible subsets.

**Note:** The solution set must not contain duplicate subsets. 

For example,

If **_nums_** = `[1,2,2]`, a solution is:

[Subscribe](/subscribe/) to see which companies asked this question.



[Subsets II](https://leetcode.com/problems/subsets-ii)

# Solution



