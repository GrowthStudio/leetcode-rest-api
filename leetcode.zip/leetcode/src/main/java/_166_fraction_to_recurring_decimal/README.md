
# Problem

Given two integers representing the numerator and denominator of a fraction,
return the fraction in string format.

If the fractional part is repeating, enclose the repeating part in
parentheses.

For example,

**Credits:**  
Special thanks to [@Shangrila](https://oj.leetcode.com/discuss/user/Shangrila)
for adding this problem and creating all test cases.

[Subscribe](/subscribe/) to see which companies asked this question.



[Fraction to Recurring Decimal](https://leetcode.com/problems/fraction-to-recurring-decimal)

# Solution



