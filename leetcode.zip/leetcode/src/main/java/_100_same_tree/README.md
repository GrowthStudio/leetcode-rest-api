
# Problem

Given two binary trees, write a function to check if they are equal or not.

Two binary trees are considered equal if they are structurally identical and
the nodes have the same value.

[Subscribe](/subscribe/) to see which companies asked this question.



[Same Tree](https://leetcode.com/problems/same-tree)

# Solution



