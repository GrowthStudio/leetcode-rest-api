
# Problem

Design a stack that supports push, pop, top, and retrieving the minimum
element in constant time.

**Example:**  

[Subscribe](/subscribe/) to see which companies asked this question.



[Min Stack](https://leetcode.com/problems/min-stack)

# Solution



