
# Problem

Given a binary tree, return the _postorder_ traversal of its nodes' values.

For example:

Given binary tree `{1,#,2,3}`,

return `[3,2,1]`.

**Note:** Recursive solution is trivial, could you do it iteratively?

[Subscribe](/subscribe/) to see which companies asked this question.



[Binary Tree Postorder Traversal](https://leetcode.com/problems/binary-tree-postorder-traversal)

# Solution



