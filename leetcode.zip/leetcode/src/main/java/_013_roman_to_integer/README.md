
# Problem

Given a roman numeral, convert it to an integer.

Input is guaranteed to be within the range from 1 to 3999.

[Subscribe](/subscribe/) to see which companies asked this question.



[Roman to Integer](https://leetcode.com/problems/roman-to-integer)

# Solution



