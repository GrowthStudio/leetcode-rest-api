
package _011_container_with_most_water;

/**
 * https://leetcode.com/problems/container-with-most-water
 */
public class Solution {
    public void containerWithMostWater() {

    }
}

