
# Problem

Given _n_ non-negative integers _a1_, _a2_, ..., _an_, where each represents a
point at coordinate (_i_, _ai_). _n_ vertical lines are drawn such that the
two endpoints of line _i_ is at (_i_, _ai_) and (_i_, 0). Find two lines,
which together with x-axis forms a container, such that the container contains
the most water.

Note: You may not slant the container and _n_ is at least 2.

[Subscribe](/subscribe/) to see which companies asked this question.



[Container With Most Water](https://leetcode.com/problems/container-with-most-water)

# Solution



