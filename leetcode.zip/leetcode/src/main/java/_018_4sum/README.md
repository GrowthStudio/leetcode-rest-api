
# Problem

Given an array _S_ of _n_ integers, are there elements _a_, _b_, _c_, and _d_
in _S_ such that _a_ + _b_ + _c_ + _d_ = target? Find all unique quadruplets
in the array which gives the sum of target.

**Note:** The solution set must not contain duplicate quadruplets. 

[Subscribe](/subscribe/) to see which companies asked this question.



[4Sum](https://leetcode.com/problems/4sum)

# Solution



