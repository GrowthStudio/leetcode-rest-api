
package _127_word_ladder;

/**
 * https://leetcode.com/problems/word-ladder
 */
public class Solution {
    public void wordLadder() {

    }
}

