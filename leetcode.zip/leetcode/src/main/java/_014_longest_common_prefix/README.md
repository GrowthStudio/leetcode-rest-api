
# Problem

Write a function to find the longest common prefix string amongst an array of
strings.

[Subscribe](/subscribe/) to see which companies asked this question.



[Longest Common Prefix](https://leetcode.com/problems/longest-common-prefix)

# Solution



