
package _014_longest_common_prefix;

/**
 * https://leetcode.com/problems/longest-common-prefix
 */
public class Solution {
    public void longestCommonPrefix() {

    }
}

