
package _083_remove_duplicates_from_sorted_list;

/**
 * https://leetcode.com/problems/remove-duplicates-from-sorted-list
 */
public class Solution {
    public void removeDuplicatesFromSortedList() {

    }
}

