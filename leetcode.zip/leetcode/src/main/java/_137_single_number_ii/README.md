
# Problem

Given an array of integers, every element appears _three_ times except for
one, which appears exactly once. Find that single one.

**Note:**  
Your algorithm should have a linear runtime complexity. Could you implement it
without using extra memory?

[Subscribe](/subscribe/) to see which companies asked this question.



[Single Number II](https://leetcode.com/problems/single-number-ii)

# Solution



