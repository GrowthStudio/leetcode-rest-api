
# Problem

Given an array _S_ of _n_ integers, find three integers in _S_ such that the
sum is closest to a given number, target. Return the sum of the three
integers. You may assume that each input would have exactly one solution.

[Subscribe](/subscribe/) to see which companies asked this question.



[3Sum Closest](https://leetcode.com/problems/3sum-closest)

# Solution



