
package _027_remove_element;

/**
 * https://leetcode.com/problems/remove-element
 */
public class Solution {
    public void removeElement() {

    }
}

