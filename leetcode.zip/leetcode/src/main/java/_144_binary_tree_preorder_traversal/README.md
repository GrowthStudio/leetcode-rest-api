
# Problem

Given a binary tree, return the _preorder_ traversal of its nodes' values.

For example:

Given binary tree `{1,#,2,3}`,

return `[1,2,3]`.

**Note:** Recursive solution is trivial, could you do it iteratively?

[Subscribe](/subscribe/) to see which companies asked this question.



[Binary Tree Preorder Traversal](https://leetcode.com/problems/binary-tree-preorder-traversal)

# Solution



