
# Problem

Given an integer _n_, generate a square matrix filled with elements from 1 to
_n_2 in spiral order.

For example,

Given _n_ = `3`,

[Subscribe](/subscribe/) to see which companies asked this question.



[Spiral Matrix II](https://leetcode.com/problems/spiral-matrix-ii)

# Solution



