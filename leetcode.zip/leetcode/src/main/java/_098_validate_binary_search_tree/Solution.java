
package _098_validate_binary_search_tree;

/**
 * https://leetcode.com/problems/validate-binary-search-tree
 */
public class Solution {
    public void validateBinarySearchTree() {

    }
}

