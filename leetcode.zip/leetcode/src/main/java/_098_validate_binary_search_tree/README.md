
# Problem

Given a binary tree, determine if it is a valid binary search tree (BST).

Assume a BST is defined as follows:

**Example 1:**  

**Example 2:**  

[Subscribe](/subscribe/) to see which companies asked this question.



[Validate Binary Search Tree](https://leetcode.com/problems/validate-binary-search-tree)

# Solution



