
package _157_read_n_characters_given_read4;

/**
 * https://leetcode.com/problems/read-n-characters-given-read4
 */
public class Solution {
    public void readNCharactersGivenRead4() {

    }
}

