
# Problem





[Read N Characters Given Read4](https://leetcode.com/problems/read-n-characters-given-read4)

# Solution



