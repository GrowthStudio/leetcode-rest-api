
package _056_merge_intervals;

/**
 * https://leetcode.com/problems/merge-intervals
 */
public class Solution {
    public void mergeIntervals() {

    }
}

