
package _128_longest_consecutive_sequence;

/**
 * https://leetcode.com/problems/longest-consecutive-sequence
 */
public class Solution {
    public void longestConsecutiveSequence() {

    }
}

