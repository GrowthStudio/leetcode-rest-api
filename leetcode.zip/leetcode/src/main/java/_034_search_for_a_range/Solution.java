
package _034_search_for_a_range;

/**
 * https://leetcode.com/problems/search-for-a-range
 */
public class Solution {
    public void searchForARange() {

    }
}

