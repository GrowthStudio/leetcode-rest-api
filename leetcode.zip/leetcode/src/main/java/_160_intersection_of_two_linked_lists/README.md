
# Problem

Write a program to find the node at which the intersection of two singly
linked lists begins.

For example, the following two linked lists:

begin to intersect at node c1.

**Notes:**

**Credits:**  
Special thanks to [@stellari](https://oj.leetcode.com/discuss/user/stellari)
for adding this problem and creating all test cases.

[Subscribe](/subscribe/) to see which companies asked this question.



[Intersection of Two Linked Lists](https://leetcode.com/problems/intersection-of-two-linked-lists)

# Solution



