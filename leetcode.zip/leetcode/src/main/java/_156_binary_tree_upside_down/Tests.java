
package _156_binary_tree_upside_down;
import org.junit.*;

public class Tests {
	private Solution solution = new Solution();

	@Test public void test1() {

	}

    @Test public void test2() {

	}
}

