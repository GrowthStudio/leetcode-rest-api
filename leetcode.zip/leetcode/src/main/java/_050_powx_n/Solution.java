
package _050_powx_n;

/**
 * https://leetcode.com/problems/powx-n
 */
public class Solution {
    public void powxN() {

    }
}

