
# Problem

Implement pow(_x_, _n_).

[Subscribe](/subscribe/) to see which companies asked this question.



[Pow(x, n)](https://leetcode.com/problems/powx-n)

# Solution



