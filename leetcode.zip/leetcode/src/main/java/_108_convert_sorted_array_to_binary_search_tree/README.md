
# Problem

Given an array where elements are sorted in ascending order, convert it to a
height balanced BST.

[Subscribe](/subscribe/) to see which companies asked this question.



[Convert Sorted Array to Binary Search Tree](https://leetcode.com/problems/convert-sorted-array-to-binary-search-tree)

# Solution



