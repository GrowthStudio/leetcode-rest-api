
# Problem

Two elements of a binary search tree (BST) are swapped by mistake.

Recover the tree without changing its structure.

[Subscribe](/subscribe/) to see which companies asked this question.



[Recover Binary Search Tree](https://leetcode.com/problems/recover-binary-search-tree)

# Solution



