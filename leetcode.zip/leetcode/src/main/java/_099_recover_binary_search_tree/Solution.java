
package _099_recover_binary_search_tree;

/**
 * https://leetcode.com/problems/recover-binary-search-tree
 */
public class Solution {
    public void recoverBinarySearchTree() {

    }
}

