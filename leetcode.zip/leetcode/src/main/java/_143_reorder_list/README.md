
# Problem

Given a singly linked list _L_: _L_0→_L_1→…→_L__n_-1→_L_n,

reorder it to: _L_0→_L__n_→_L_1→_L__n_-1→_L_2→_L__n_-2→…

You must do this in-place without altering the nodes' values.

For example,

Given `{1,2,3,4}`, reorder it to `{1,4,2,3}`.

[Subscribe](/subscribe/) to see which companies asked this question.



[Reorder List](https://leetcode.com/problems/reorder-list)

# Solution



