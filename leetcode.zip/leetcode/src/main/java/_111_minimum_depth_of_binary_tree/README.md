
# Problem

Given a binary tree, find its minimum depth.

The minimum depth is the number of nodes along the shortest path from the root
node down to the nearest leaf node.

[Subscribe](/subscribe/) to see which companies asked this question.



[Minimum Depth of Binary Tree](https://leetcode.com/problems/minimum-depth-of-binary-tree)

# Solution



