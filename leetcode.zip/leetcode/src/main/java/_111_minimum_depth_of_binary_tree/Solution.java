
package _111_minimum_depth_of_binary_tree;

/**
 * https://leetcode.com/problems/minimum-depth-of-binary-tree
 */
public class Solution {
    public void minimumDepthOfBinaryTree() {

    }
}

