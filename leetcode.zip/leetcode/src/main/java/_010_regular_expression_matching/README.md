
# Problem

Implement regular expression matching with support for `'.'` and `'*'`.

[Subscribe](/subscribe/) to see which companies asked this question.



[Regular Expression Matching](https://leetcode.com/problems/regular-expression-matching)

# Solution



