
# Problem

Given a string _s_, partition _s_ such that every substring of the partition
is a palindrome.

Return the minimum cuts needed for a palindrome partitioning of _s_.

For example, given _s_ = `"aab"`,

Return `1` since the palindrome partitioning `["aa","b"]` could be produced
using 1 cut.

[Subscribe](/subscribe/) to see which companies asked this question.



[Palindrome Partitioning II](https://leetcode.com/problems/palindrome-partitioning-ii)

# Solution



