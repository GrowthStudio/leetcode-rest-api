
# Problem

There are _N_ children standing in a line. Each child is assigned a rating
value.

You are giving candies to these children subjected to the following
requirements:

What is the minimum candies you must give?

[Subscribe](/subscribe/) to see which companies asked this question.



[Candy](https://leetcode.com/problems/candy)

# Solution



