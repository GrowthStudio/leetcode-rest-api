
package _135_candy;

/**
 * https://leetcode.com/problems/candy
 */
public class Solution {
    public void candy() {

    }
}

