
package _028_implement_strstr;

/**
 * https://leetcode.com/problems/implement-strstr
 */
public class Solution {
    public void implementStrstr() {

    }
}

