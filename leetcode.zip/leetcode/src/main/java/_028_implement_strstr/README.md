
# Problem

Implement strStr().

Returns the index of the first occurrence of needle in haystack, or -1 if
needle is not part of haystack.

[Subscribe](/subscribe/) to see which companies asked this question.



[Implement strStr()](https://leetcode.com/problems/implement-strstr)

# Solution



