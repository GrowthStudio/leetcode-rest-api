
# Problem

Say you have an array for which the _i_th element is the price of a given
stock on day _i_.

Design an algorithm to find the maximum profit. You may complete at most _two_
transactions.

**Note:**  
You may not engage in multiple transactions at the same time (ie, you must
sell the stock before you buy again).

[Subscribe](/subscribe/) to see which companies asked this question.



[Best Time to Buy and Sell Stock III](https://leetcode.com/problems/best-time-to-buy-and-sell-stock-iii)

# Solution



