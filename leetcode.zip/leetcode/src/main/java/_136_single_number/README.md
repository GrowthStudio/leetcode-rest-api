
# Problem

Given an array of integers, every element appears _twice_ except for one. Find
that single one.

**Note:**  
Your algorithm should have a linear runtime complexity. Could you implement it
without using extra memory?

[Subscribe](/subscribe/) to see which companies asked this question.



[Single Number](https://leetcode.com/problems/single-number)

# Solution



