
# Problem

Given _n_ pairs of parentheses, write a function to generate all combinations
of well-formed parentheses.

For example, given _n_ = 3, a solution set is:

[Subscribe](/subscribe/) to see which companies asked this question.



[Generate Parentheses](https://leetcode.com/problems/generate-parentheses)

# Solution



