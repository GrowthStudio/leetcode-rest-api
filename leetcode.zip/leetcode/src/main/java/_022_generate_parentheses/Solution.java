
package _022_generate_parentheses;

/**
 * https://leetcode.com/problems/generate-parentheses
 */
public class Solution {
    public void generateParentheses() {

    }
}

