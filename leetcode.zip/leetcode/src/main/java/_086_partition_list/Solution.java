
package _086_partition_list;

/**
 * https://leetcode.com/problems/partition-list
 */
public class Solution {
    public void partitionList() {

    }
}

