
package _159_longest_substring_with_at_most_two_distinct_characters;

/**
 * https://leetcode.com/problems/longest-substring-with-at-most-two-distinct-characters
 */
public class Solution {
    public void longestSubstringWithAtMostTwoDistinctCharacters() {

    }
}

