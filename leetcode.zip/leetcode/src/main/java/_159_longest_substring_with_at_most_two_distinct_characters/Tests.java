
package _159_longest_substring_with_at_most_two_distinct_characters;
import org.junit.*;

public class Tests {
	private Solution solution = new Solution();

	@Test public void test1() {

	}

    @Test public void test2() {

	}
}

