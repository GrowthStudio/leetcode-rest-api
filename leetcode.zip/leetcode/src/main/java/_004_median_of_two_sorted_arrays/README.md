
# Problem

There are two sorted arrays **nums1** and **nums2** of size m and n
respectively.

Find the median of the two sorted arrays. The overall run time complexity
should be O(log (m+n)).

**Example 1:**  

**Example 2:**  

[Subscribe](/subscribe/) to see which companies asked this question.



[Median of Two Sorted Arrays](https://leetcode.com/problems/median-of-two-sorted-arrays)

# Solution



