
package _009_palindrome_number;

/**
 * https://leetcode.com/problems/palindrome-number
 */
public class Solution {
    public void palindromeNumber() {

    }
}

