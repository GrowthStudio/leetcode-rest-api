
# Problem

Say you have an array for which the _i_th element is the price of a given
stock on day _i_.

If you were only permitted to complete at most one transaction (ie, buy one
and sell one share of the stock), design an algorithm to find the maximum
profit.

**Example 1:**  

**Example 2:**  

[Subscribe](/subscribe/) to see which companies asked this question.



[Best Time to Buy and Sell Stock](https://leetcode.com/problems/best-time-to-buy-and-sell-stock)

# Solution



