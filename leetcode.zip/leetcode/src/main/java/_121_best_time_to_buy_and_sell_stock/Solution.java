
package _121_best_time_to_buy_and_sell_stock;

/**
 * https://leetcode.com/problems/best-time-to-buy-and-sell-stock
 */
public class Solution {
    public void bestTimeToBuyAndSellStock() {

    }
}

