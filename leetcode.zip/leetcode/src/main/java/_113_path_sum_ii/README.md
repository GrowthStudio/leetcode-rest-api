
# Problem

Given a binary tree and a sum, find all root-to-leaf paths where each path's
sum equals the given sum.

return

[Subscribe](/subscribe/) to see which companies asked this question.



[Path Sum II](https://leetcode.com/problems/path-sum-ii)

# Solution



