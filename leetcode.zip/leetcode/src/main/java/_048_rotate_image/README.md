
# Problem

You are given an _n_ x _n_ 2D matrix representing an image.

Rotate the image by 90 degrees (clockwise).

Follow up:

Could you do this in-place?

[Subscribe](/subscribe/) to see which companies asked this question.



[Rotate Image](https://leetcode.com/problems/rotate-image)

# Solution



