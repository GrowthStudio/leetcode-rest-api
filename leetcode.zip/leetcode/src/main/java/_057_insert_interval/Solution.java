
package _057_insert_interval;

/**
 * https://leetcode.com/problems/insert-interval
 */
public class Solution {
    public void insertInterval() {

    }
}

