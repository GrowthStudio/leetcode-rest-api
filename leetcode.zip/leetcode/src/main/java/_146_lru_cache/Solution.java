
package _146_lru_cache;

/**
 * https://leetcode.com/problems/lru-cache
 */
public class Solution {
    public void lruCache() {

    }
}

