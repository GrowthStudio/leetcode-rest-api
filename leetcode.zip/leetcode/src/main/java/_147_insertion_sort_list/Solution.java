
package _147_insertion_sort_list;

/**
 * https://leetcode.com/problems/insertion-sort-list
 */
public class Solution {
    public void insertionSortList() {

    }
}

