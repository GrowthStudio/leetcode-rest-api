
# Problem

Given two integers _n_ and _k_, return all possible combinations of _k_
numbers out of 1 ... _n_.

For example,

If _n_ = 4 and _k_ = 2, a solution is:

[Subscribe](/subscribe/) to see which companies asked this question.



[Combinations](https://leetcode.com/problems/combinations)

# Solution



