
package _077_combinations;
import org.junit.*;

public class Tests {
	private Solution solution = new Solution();

	@Test public void test1() {

	}

    @Test public void test2() {

	}
}

