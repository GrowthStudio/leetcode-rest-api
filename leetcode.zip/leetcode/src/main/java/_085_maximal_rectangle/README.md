
# Problem

Given a 2D binary matrix filled with 0's and 1's, find the largest rectangle
containing only 1's and return its area.

For example, given the following matrix:

[Subscribe](/subscribe/) to see which companies asked this question.



[Maximal Rectangle](https://leetcode.com/problems/maximal-rectangle)

# Solution



