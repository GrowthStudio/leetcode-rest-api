
# Problem

Given a string **s**, find the longest palindromic substring in **s**. You may
assume that the maximum length of **s** is 1000.

**Example:**

**Example:**

[Subscribe](/subscribe/) to see which companies asked this question.



[Longest Palindromic Substring](https://leetcode.com/problems/longest-palindromic-substring)

# Solution



