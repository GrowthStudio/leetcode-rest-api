
# Problem

Given a set of **distinct** integers, _nums_, return all possible subsets.

**Note:** The solution set must not contain duplicate subsets. 

For example,

If **_nums_** = `[1,2,3]`, a solution is:

[Subscribe](/subscribe/) to see which companies asked this question.



[Subsets](https://leetcode.com/problems/subsets)

# Solution



