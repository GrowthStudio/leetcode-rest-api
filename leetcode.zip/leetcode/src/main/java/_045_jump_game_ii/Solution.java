
package _045_jump_game_ii;

/**
 * https://leetcode.com/problems/jump-game-ii
 */
public class Solution {
    public void jumpGameIi() {

    }
}

