
# Problem

Given an integer _n_, generate all structurally unique **BST's** (binary
search trees) that store values 1..._n_.

For example,

Given _n_ = 3, your program should return all 5 unique BST's shown below.

[Subscribe](/subscribe/) to see which companies asked this question.



[Unique Binary Search Trees II](https://leetcode.com/problems/unique-binary-search-trees-ii)

# Solution



