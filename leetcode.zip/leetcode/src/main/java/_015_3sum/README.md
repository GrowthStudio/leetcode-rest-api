
# Problem

Given an array _S_ of _n_ integers, are there elements _a_, _b_, _c_ in _S_
such that _a_ + _b_ + _c_ = 0? Find all unique triplets in the array which
gives the sum of zero.

**Note:** The solution set must not contain duplicate triplets.

[Subscribe](/subscribe/) to see which companies asked this question.



[3Sum](https://leetcode.com/problems/3sum)

# Solution



