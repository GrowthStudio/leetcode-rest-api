
package _024_swap_nodes_in_pairs;

/**
 * https://leetcode.com/problems/swap-nodes-in-pairs
 */
public class Solution {
    public void swapNodesInPairs() {

    }
}

