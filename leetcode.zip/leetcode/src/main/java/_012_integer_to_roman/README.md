
# Problem

Given an integer, convert it to a roman numeral.

Input is guaranteed to be within the range from 1 to 3999.

[Subscribe](/subscribe/) to see which companies asked this question.



[Integer to Roman](https://leetcode.com/problems/integer-to-roman)

# Solution



