
package _051_n_queens;

/**
 * https://leetcode.com/problems/n-queens
 */
public class Solution {
    public void nQueens() {

    }
}

