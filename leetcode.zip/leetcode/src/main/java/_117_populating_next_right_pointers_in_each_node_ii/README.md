
# Problem

Follow up for problem "_Populating Next Right Pointers in Each Node_".

What if the given tree could be any binary tree? Would your previous solution
still work?

**Note:**

For example,

Given the following binary tree,

After calling your function, the tree should look like:

[Subscribe](/subscribe/) to see which companies asked this question.



[Populating Next Right Pointers in Each Node II](https://leetcode.com/problems/populating-next-right-pointers-in-each-node-ii)

# Solution



