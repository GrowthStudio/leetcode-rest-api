
package _066_plus_one;

/**
 * https://leetcode.com/problems/plus-one
 */
public class Solution {
    public void plusOne() {

    }
}

