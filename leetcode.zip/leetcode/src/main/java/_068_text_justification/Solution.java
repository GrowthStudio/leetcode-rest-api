
package _068_text_justification;

/**
 * https://leetcode.com/problems/text-justification
 */
public class Solution {
    public void textJustification() {

    }
}

