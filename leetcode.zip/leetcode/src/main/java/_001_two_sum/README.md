
# Problem

Given an array of integers, return **indices** of the two numbers such that
they add up to a specific target.

You may assume that each input would have **_exactly_** one solution, and you
may not use the _same_ element twice.

**Example:**  

[Subscribe](/subscribe/) to see which companies asked this question.



[Two Sum](https://leetcode.com/problems/two-sum)

# Solution



