
package _001_two_sum;

/**
 * https://leetcode.com/problems/two-sum
 */
public class Solution {
    public void twoSum() {

    }
}

