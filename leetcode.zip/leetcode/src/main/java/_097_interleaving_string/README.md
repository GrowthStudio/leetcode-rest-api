
# Problem

Given _s1_, _s2_, _s3_, find whether _s3_ is formed by the interleaving of
_s1_ and _s2_.

For example,

Given:

_s1_ = `"aabcc"`,

_s2_ = `"dbbca"`,

When _s3_ = `"aadbbcbcac"`, return true.

When _s3_ = `"aadbbbaccc"`, return false.

[Subscribe](/subscribe/) to see which companies asked this question.



[Interleaving String](https://leetcode.com/problems/interleaving-string)

# Solution



