
# Problem

Given _n_, how many structurally unique **BST's** (binary search trees) that
store values 1..._n_?

For example,

Given _n_ = 3, there are a total of 5 unique BST's.

[Subscribe](/subscribe/) to see which companies asked this question.



[Unique Binary Search Trees](https://leetcode.com/problems/unique-binary-search-trees)

# Solution



