
# Problem

Given _n_ points on a 2D plane, find the maximum number of points that lie on
the same straight line.

[Subscribe](/subscribe/) to see which companies asked this question.



[Max Points on a Line](https://leetcode.com/problems/max-points-on-a-line)

# Solution



