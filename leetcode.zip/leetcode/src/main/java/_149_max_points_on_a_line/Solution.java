
package _149_max_points_on_a_line;

/**
 * https://leetcode.com/problems/max-points-on-a-line
 */
public class Solution {
    public void maxPointsOnALine() {

    }
}

