
package _139_word_break;

/**
 * https://leetcode.com/problems/word-break
 */
public class Solution {
    public void wordBreak() {

    }
}

