
package _120_triangle;

/**
 * https://leetcode.com/problems/triangle
 */
public class Solution {
    public void triangle() {

    }
}

