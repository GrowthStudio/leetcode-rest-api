
package _079_word_search;
import org.junit.*;

public class Tests {
	private Solution solution = new Solution();

	@Test public void test1() {

	}

    @Test public void test2() {

	}
}

