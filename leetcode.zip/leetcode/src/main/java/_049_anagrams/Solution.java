
package _049_anagrams;

/**
 * https://leetcode.com/problems/anagrams
 */
public class Solution {
    public void anagrams() {

    }
}

