
# Problem

Given an array of strings, group anagrams together.

For example, given: `["eat", "tea", "tan", "ate", "nat", "bat"]`,

Return:

**Note:** All inputs will be in lower-case.

[Subscribe](/subscribe/) to see which companies asked this question.



[Group Anagrams](https://leetcode.com/problems/anagrams)

# Solution



