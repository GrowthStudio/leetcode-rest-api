
# Problem

Merge two sorted linked lists and return it as a new list. The new list should
be made by splicing together the nodes of the first two lists.

[Subscribe](/subscribe/) to see which companies asked this question.



[Merge Two Sorted Lists](https://leetcode.com/problems/merge-two-sorted-lists)

# Solution



