
# Problem

Given an index _k_, return the _k_th row of the Pascal's triangle.

For example, given _k_ = 3,

Return `[1,3,3,1]`.

**Note:**  
Could you optimize your algorithm to use only _O_(_k_) extra space?

[Subscribe](/subscribe/) to see which companies asked this question.



[Pascal's Triangle II](https://leetcode.com/problems/pascals-triangle-ii)

# Solution



