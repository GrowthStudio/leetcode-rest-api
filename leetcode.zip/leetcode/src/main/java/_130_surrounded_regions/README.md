
# Problem

Given a 2D board containing `'X'` and `'O'` (the **letter** O), capture all
regions surrounded by `'X'`.

A region is captured by flipping all `'O'`s into `'X'`s in that surrounded
region.

For example,

After running your function, the board should be:

[Subscribe](/subscribe/) to see which companies asked this question.



[Surrounded Regions](https://leetcode.com/problems/surrounded-regions)

# Solution



