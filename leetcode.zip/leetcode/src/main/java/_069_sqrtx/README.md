
# Problem

Implement `int sqrt(int x)`.

Compute and return the square root of _x_.

[Subscribe](/subscribe/) to see which companies asked this question.



[Sqrt(x)](https://leetcode.com/problems/sqrtx)

# Solution



