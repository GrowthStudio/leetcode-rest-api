
package _069_sqrtx;

/**
 * https://leetcode.com/problems/sqrtx
 */
public class Solution {
    public void sqrtx() {

    }
}

