
# Problem

Given a collection of numbers that might contain duplicates, return all
possible unique permutations.

For example,

`[1,1,2]` have the following unique permutations:

[Subscribe](/subscribe/) to see which companies asked this question.



[Permutations II](https://leetcode.com/problems/permutations-ii)

# Solution



