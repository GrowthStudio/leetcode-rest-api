
package _046_permutations;

/**
 * https://leetcode.com/problems/permutations
 */
public class Solution {
    public void permutations() {

    }
}

