
# Problem

Given a collection of **distinct** numbers, return all possible permutations.

For example,

`[1,2,3]` have the following permutations:

[Subscribe](/subscribe/) to see which companies asked this question.



[Permutations](https://leetcode.com/problems/permutations)

# Solution



