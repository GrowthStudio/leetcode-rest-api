
package _020_valid_parentheses;

/**
 * https://leetcode.com/problems/valid-parentheses
 */
public class Solution {
    public void validParentheses() {

    }
}

