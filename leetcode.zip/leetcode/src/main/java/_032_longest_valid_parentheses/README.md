
# Problem

Given a string containing just the characters `'('` and `')'`, find the length
of the longest valid (well-formed) parentheses substring.

For `"(()"`, the longest valid parentheses substring is `"()"`, which has
length = 2.

Another example is `")()())"`, where the longest valid parentheses substring
is `"()()"`, which has length = 4.

[Subscribe](/subscribe/) to see which companies asked this question.



[Longest Valid Parentheses](https://leetcode.com/problems/longest-valid-parentheses)

# Solution



