
package _031_next_permutation;

/**
 * https://leetcode.com/problems/next-permutation
 */
public class Solution {
    public void nextPermutation() {

    }
}

