
# Problem

Given a binary tree, flatten it to a linked list in-place.

For example,

Given

click to show hints.

If you notice carefully in the flattened tree, each node's right child points
to the next node of a pre-order traversal.

[Subscribe](/subscribe/) to see which companies asked this question.



[Flatten Binary Tree to Linked List](https://leetcode.com/problems/flatten-binary-tree-to-linked-list)

# Solution



