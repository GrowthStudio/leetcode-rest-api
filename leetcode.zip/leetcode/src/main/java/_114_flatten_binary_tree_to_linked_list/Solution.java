
package _114_flatten_binary_tree_to_linked_list;

/**
 * https://leetcode.com/problems/flatten-binary-tree-to-linked-list
 */
public class Solution {
    public void flattenBinaryTreeToLinkedList() {

    }
}

