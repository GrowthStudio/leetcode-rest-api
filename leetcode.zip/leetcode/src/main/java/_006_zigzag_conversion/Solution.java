
package _006_zigzag_conversion;

/**
 * https://leetcode.com/problems/zigzag-conversion
 */
public class Solution {
    public void zigzagConversion() {

    }
}

