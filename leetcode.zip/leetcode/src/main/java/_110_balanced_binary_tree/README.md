
# Problem

Given a binary tree, determine if it is height-balanced.

For this problem, a height-balanced binary tree is defined as a binary tree in
which the depth of the two subtrees of _every_ node never differ by more than
1.

[Subscribe](/subscribe/) to see which companies asked this question.



[Balanced Binary Tree](https://leetcode.com/problems/balanced-binary-tree)

# Solution



