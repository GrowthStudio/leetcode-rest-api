
# Problem

Write an efficient algorithm that searches for a value in an _m_ x _n_ matrix.
This matrix has the following properties:

For example,

Consider the following matrix:

Given **target** = `3`, return `true`.

[Subscribe](/subscribe/) to see which companies asked this question.



[Search a 2D Matrix](https://leetcode.com/problems/search-a-2d-matrix)

# Solution



