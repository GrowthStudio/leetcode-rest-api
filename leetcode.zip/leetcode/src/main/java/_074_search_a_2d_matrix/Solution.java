
package _074_search_a_2d_matrix;

/**
 * https://leetcode.com/problems/search-a-2d-matrix
 */
public class Solution {
    public void searchA2dMatrix() {

    }
}

