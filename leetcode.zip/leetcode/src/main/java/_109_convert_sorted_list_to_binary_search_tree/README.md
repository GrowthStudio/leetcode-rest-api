
# Problem

Given a singly linked list where elements are sorted in ascending order,
convert it to a height balanced BST.

[Subscribe](/subscribe/) to see which companies asked this question.



[Convert Sorted List to Binary Search Tree](https://leetcode.com/problems/convert-sorted-list-to-binary-search-tree)

# Solution



