
package _167_two_sum_ii_input_array_is_sorted;

/**
 * https://leetcode.com/problems/two-sum-ii-input-array-is-sorted
 */
public class Solution {
    public void twoSumIiInputArrayIsSorted() {

    }
}

