
package _158_read_n_characters_given_read4_ii_call_multiple_times;

/**
 * https://leetcode.com/problems/read-n-characters-given-read4-ii-call-multiple-times
 */
public class Solution {
    public void readNCharactersGivenRead4IiCallMultipleTimes() {

    }
}

