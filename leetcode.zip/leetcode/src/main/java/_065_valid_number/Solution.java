
package _065_valid_number;

/**
 * https://leetcode.com/problems/valid-number
 */
public class Solution {
    public void validNumber() {

    }
}

