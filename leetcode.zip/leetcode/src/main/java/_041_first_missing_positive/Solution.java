
package _041_first_missing_positive;

/**
 * https://leetcode.com/problems/first-missing-positive
 */
public class Solution {
    public void firstMissingPositive() {

    }
}

