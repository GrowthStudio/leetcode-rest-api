
package _148_sort_list;

/**
 * https://leetcode.com/problems/sort-list
 */
public class Solution {
    public void sortList() {

    }
}

