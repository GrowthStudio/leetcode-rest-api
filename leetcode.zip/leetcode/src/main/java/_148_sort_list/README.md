
# Problem

Sort a linked list in _O_(_n_ log _n_) time using constant space complexity.

[Subscribe](/subscribe/) to see which companies asked this question.



[Sort List](https://leetcode.com/problems/sort-list)

# Solution



